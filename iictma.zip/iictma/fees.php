<?php

include("db.php");

$students = mysqli_query($conn,"SELECT id,StudentName FROM iicttv");

?>

<!DOCTYPE html>

<html>

<head>

<title>Fee Management</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<h2 align="center">Student Fee Management</h2>

<form action="save_fee.php" method="POST">

<label>Student</label>

<select name="StudentID" required>

<option value="">Select Student</option>

<?php

while($row=mysqli_fetch_assoc($students))
{

?>

<option value="<?php echo $row['id']; ?>">

<?php echo $row['StudentName']; ?>

</option>

<?php

}

?>

</select>

<br><br>

<label>Total Fee</label>

<input type="number" name="TotalFee" required>

<br><br>

<label>Paid Fee</label>

<input type="number" name="PaidFee" required>

<br><br>

<label>Payment Date</label>

<input type="date" name="PaymentDate" required>

<br><br>

<button type="submit" name="save">

Save Fee

</button>

</form>

</body>

</html>