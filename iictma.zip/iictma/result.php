<?php

include("db.php");

$students = mysqli_query($conn,"SELECT id,StudentName FROM iicttv");

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Result</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<h2 align="center">

Add Student Result

</h2>

<form action="save_result.php" method="POST">

<label>Student</label>

<select name="StudentID" required>

<option value="">Select Student</option>

<?php

while($row=mysqli_fetch_assoc($students))
{

?>

<option value="<?php echo $row['id']; ?>">

<?php echo $row['StudentName']; ?>

</option>

<?php

}

?>

</select>

<br><br>

<label>Course</label>

<input
type="text"
name="Course"
required>

<br><br>

<label>Subject</label>

<input
type="text"
name="Subject"
required>

<br><br>

<label>Total Marks</label>

<input
type="number"
name="TotalMarks"
required>

<br><br>

<label>Obtained Marks</label>

<input
type="number"
name="ObtainedMarks"
required>

<br><br>

<label>Result Date</label>

<input
type="date"
name="ResultDate"
required>

<br><br>

<button
type="submit"
name="save">

Save Result

</button>

</form>

</body>

</html>