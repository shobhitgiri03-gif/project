<?php

include("db.php");

date_default_timezone_set("Asia/Kolkata");

$id = $_GET['id'];

$sql = "SELECT * FROM iicttv WHERE id='$id'";

$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>

<html>

<head>

<title>Student ID Card</title>

<hr>

<div style="display:flex;justify-content:space-between;">

<div>

____________________

<br>

Student Signature

</div>

<div>

____________________

<br>

Authorized Signature

</div>

</div>

<style>

body{
font-family:Arial;
background:#f5f5f5;
}

.card{

width:350px;

margin:40px auto;

background:white;

border:3px solid #0d6efd;

border-radius:15px;

text-align:center;

padding:20px;

}

.photo{

width:120px;

height:120px;

border-radius:50%;

border:3px solid #0d6efd;

object-fit:cover;

}

h2{

color:#0d6efd;

margin:10px;

}

table{

width:100%;

margin-top:15px;

}

table td{

padding:8px;

text-align:left;

}

button{

margin-top:20px;

padding:10px 20px;

background:#0d6efd;

color:white;

border:none;

cursor:pointer;

}

</style>

</head>

<body>

<div class="card">

<h2>IICT COMPUTER CLASSES</h2>

<img src="uploads/<?php echo $row['ProfilePhoto']; ?>" class="photo">

<h3><?php echo $row['StudentName']; ?></h3>

<table>

<tr>

<td><b>ID</b></td>

<td><?php echo $row['id']; ?></td>

</tr>

<tr>

<td><b>Course</b></td>

<td><?php echo $row['Course']; ?></td>

</tr>

<tr>

<td><b>Mobile</b></td>

<td><?php echo $row['MobileNumber']; ?></td>

</tr>

<tr>

<td><b>Email</b></td>

<td><?php echo $row['EmailAddress']; ?></td>

</tr>

<tr>
<td><b>Father</b></td>
<td><?php echo $row['FatherName']; ?></td>
</tr>

<tr>
<td><b>Admission</b></td>
<td><?php echo date("d-m-Y"); ?></td>
</tr>

</table>

<hr>

<p style="font-size:12px;">
IICT Computer Center<br>
89/77/2, Chaddha Road,<br>
Prayagraj - 211003
</p>

<button onclick="window.print()">

Print ID Card

</button>

</div>

</body>

</html>