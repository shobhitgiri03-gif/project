<?php

include("db.php");

$sql = "SELECT fees.*, iicttv.StudentName
FROM fees
INNER JOIN iicttv
ON fees.StudentID = iicttv.id
ORDER BY FeeID DESC";

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Fee Report</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{
font-family:Arial;
margin:20px;
background:#f5f5f5;
}

table{
width:100%;
border-collapse:collapse;
background:white;
}

table th,
table td{
border:1px solid #ddd;
padding:10px;
text-align:center;
}

table th{
background:#0d6efd;
color:white;
}

.paid{
background:green;
color:white;
padding:5px 10px;
border-radius:5px;
}

.pending{
background:red;
color:white;
padding:5px 10px;
border-radius:5px;
}

</style>

</head>

<body>

<h2 align="center">

Student Fee Report

</h2>

<table>

<tr>

<th>Fee ID</th>

<th>Student Name</th>

<th>Total Fee</th>

<th>Paid Fee</th>

<th>Pending Fee</th>

<th>Payment Date</th>

<th>Status</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['FeeID']; ?></td>

<td><?php echo $row['StudentName']; ?></td>

<td><?php echo $row['TotalFee']; ?></td>

<td><?php echo $row['PaidFee']; ?></td>

<td><?php echo $row['PendingFee']; ?></td>

<td><?php echo $row['PaymentDate']; ?></td>

<td>

<?php

if($row['Status']=="Paid")
{

echo "<span class='paid'>Paid</span>";

}
else
{

echo "<span class='pending'>Pending</span>";

}

?>

</td>

</tr>

<?php

}

?>

</table>

</body>

</html>