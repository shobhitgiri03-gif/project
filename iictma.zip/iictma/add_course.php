<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Course</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            padding: 50px;
        }
        form {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-top: 15px;
            color: #333;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            margin-top: 20px;
            padding: 12px 25px;
            background: #0d6efd;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }
        button:hover {
            background: #0b5ed7;
        }
    </style>
</head>
<body>
    <form action="insert_course.php" method="POST" enctype="multipart/form-data">
        <h2>Add New Course</h2>
        <label for="course_name">Course Name</label>
        <input type="text" name="course_name" id="course_name" required>
        <label for="description">Description</label>
        <textarea name="description" id="description" rows="5" required></textarea>
        <label for="image">Course Image</label>
        <input type="file" name="image" id="image" accept="image/*" required>
        <button type="submit">Add Course</button>
    </form>
</body>
</html>