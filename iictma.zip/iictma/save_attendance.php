<?php

include("db.php");

if(isset($_POST['save']))
{

    $StudentID = $_POST['StudentID'];
    $AttendanceDate = $_POST['AttendanceDate'];
    $Status = $_POST['Status'];

    $sql = "INSERT INTO attendance
    (StudentID,AttendanceDate,Status)
    VALUES
    ('$StudentID','$AttendanceDate','$Status')";

    if(mysqli_query($conn,$sql))
    {

        // Student Name Fetch
        $student = mysqli_query($conn,"SELECT StudentName FROM iicttv WHERE id='$StudentID'");
        $data = mysqli_fetch_assoc($student);

        $StudentName = $data['StudentName'];

        // Activity Log
        $date = date("Y-m-d H:i:s");

        mysqli_query($conn,"
        INSERT INTO activity_log
        (StudentName,Activity,ActivityDate)
        VALUES
        ('$StudentName','Attendance Marked','$date')
        ");

        echo "<script>

        alert('Attendance Saved Successfully');

        window.location='attendance_report.php';

        </script>";

    }
    else
    {

        echo mysqli_error($conn);

    }

}

?>