<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

$id=$_GET['id'];

$sql="SELECT
fees.*,
iicttv.StudentName,
iicttv.FatherName,
iicttv.Course,
iicttv.MobileNumber
FROM fees
INNER JOIN iicttv
ON fees.StudentID=iicttv.ID
WHERE fees.ID='$id'";

$result=mysqli_query($conn,$sql);

$row=mysqli_fetch_assoc($result);

$PendingFee=$row['TotalFee']-$row['PaidFee'];

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Fee Receipt</title>

<style>

body{

font-family:Arial;
background:#f4f6f9;

}

.receipt{

width:700px;
margin:30px auto;
background:white;
padding:30px;
border:2px solid #0d6efd;
box-shadow:0 0 10px rgba(0,0,0,.2);

}

.header{

text-align:center;
border-bottom:2px solid #0d6efd;
padding-bottom:15px;

}

.header img{

width:90px;

}

.header h1{

color:#0d6efd;
margin:10px 0;

}

table{

width:100%;
margin-top:20px;
border-collapse:collapse;

}

table td{

padding:12px;
border:1px solid #ddd;

}

.title{

background:#0d6efd;
color:white;
font-weight:bold;
width:35%;

}

.footer{

margin-top:40px;
display:flex;
justify-content:space-between;

}

button{

padding:12px 30px;
background:#198754;
color:white;
border:none;
cursor:pointer;
margin-top:30px;

}

@media print{

button{

display:none;

}

body{

background:white;

}

}

</style>

</head>

<body>

<div class="receipt">

<div class="header">

<img src="images/logo.png">

<h1>IICT Computer Classes</h1>

<h3>Fee Receipt</h3>

</div>

<table>

<tr>

<td class="title">Receipt No</td>

<td><?php echo $row['ReceiptNo']; ?></td>

</tr>

<tr>

<td class="title">Student Name</td>

<td><?php echo $row['StudentName']; ?></td>

</tr>

<tr>

<td class="title">Father Name</td>

<td><?php echo $row['FatherName']; ?></td>

</tr>

<tr>

<td class="title">Course</td>

<td><?php echo $row['Course']; ?></td>

</tr>

<tr>

<td class="title">Mobile</td>

<td><?php echo $row['MobileNumber']; ?></td>

</tr>

<tr>

<td class="title">Total Fee</td>

<td>₹ <?php echo $row['TotalFee']; ?></td>

</tr>

<tr>

<td class="title">Paid Fee</td>

<td>₹ <?php echo $row['PaidFee']; ?></td>

</tr>

<tr>

<td class="title">Pending Fee</td>

<td>₹ <?php echo $PendingFee; ?></td>

</tr>

<tr>

<td class="title">Payment Date</td>

<td><?php echo $row['FeeDate']; ?></td>

</tr>

</table>

<div class="footer">

<div>

<b>Student Signature</b>

</div>

<div>

<b>Authorized Signature</b>

</div>

</div>

<center>

<button onclick="window.print()">

Print Receipt

</button>

</center>

</div>

</body>

</html>