<?php

include("db.php");

if(isset($_GET['id']))
{

$id = $_GET['id'];

$sql = "DELETE FROM iicttv WHERE id='$id'";

$result = mysqli_query($conn,$sql);

if($result)
{

echo "<script>

alert('Student Deleted Successfully');

window.location='admin.php';

</script>";

}
else
{

echo "Delete Failed : ".mysqli_error($conn);

}

}
else
{

echo "Invalid Request";

}

?>