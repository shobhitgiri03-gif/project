<?php

include("db.php");

if(isset($_POST['send']))
{

    $StudentName = $_POST['StudentName'];
    $EmailAddress = $_POST['EmailAddress'];
    $Subject = $_POST['Subject'];
    $Message = $_POST['Message'];

    $FeedbackDate = date("Y-m-d");

    $sql = "INSERT INTO feedback
    (StudentName,EmailAddress,Subject,Message,FeedbackDate)
    VALUES
    ('$StudentName','$EmailAddress','$Subject','$Message','$FeedbackDate')";

    if(mysqli_query($conn,$sql))
    {

        echo "<script>

        alert('Thank You! Your Feedback has been submitted.');

        window.location='dashboard.php';

        </script>";

    }
    else
    {

        echo mysqli_error($conn);

    }

}
else
{

    echo "Invalid Request";

}

?>