<?php

session_start();

if(!isset($_SESSION['Admin']))
{
    header("Location: admin_login.html");
    exit();
}

include("db.php");

// Total Students
$totalStudent = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) AS total FROM iicttv"));

// Active Students
$activeStudent = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) AS active FROM iicttv WHERE Status='Active'"));

// Inactive Students
$inactiveStudent = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) AS inactive FROM iicttv WHERE Status='Inactive'"));

$sql="SELECT * FROM iicttv ORDER BY id DESC";
$result=mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>IICT Admin Panel</title>

<link rel="stylesheet" href="iict00.css">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial;
}

body{

background:#eef2f7;

}

.header{

background:#0d6efd;

color:white;

padding:20px;

display:flex;

justify-content:space-between;

align-items:center;

}

.header h1{

font-size:28px;

}

.menu{

padding:15px;

background:white;

box-shadow:0 3px 8px rgba(0,0,0,.1);

}

.menu a{

text-decoration:none;

background:#0d6efd;

color:white;

padding:10px 18px;

border-radius:5px;

margin:5px;

display:inline-block;

}

.dashboard{

display:grid;

grid-template-columns:repeat(3,1fr);

gap:20px;

padding:20px;

}

.card{

background:white;

padding:25px;

border-radius:12px;

text-align:center;

box-shadow:0 5px 15px rgba(0,0,0,.1);

}

.card h2{

font-size:40px;

margin-top:15px;

}

.total{

color:#0d6efd;

}

.active{

color:green;

}

.inactive{

color:red;

}

.content{

padding:20px;

}

</style>

</head>

<body>

<div class="header">

<h1>IICT COMPUTER CENTER</h1>

<a href="logout.php" style="color:white;text-decoration:none;">
Logout
</a>

</div>

<div class="menu">

<a href="search.php">Search</a>

<a href="export_students.php">Export Excel</a>

<a href="dashboard_stats.php">Dashboard</a>

<a href="study_material.php">Upload Notes</a>

<a href="study_material_list.php">Study Material</a>

<a href="income_report.php">Income Report</a>

<a href="activity_log.php">Activity Log</a>

<a href="settings.php">Settings</a>

<a href="backup.php">Backup</a>

</div>

<div class="dashboard">

<div class="card">

<h3>Total Students</h3>

<h2 class="total">

<?php echo $totalStudent['total']; ?>

</h2>

</div>

<div class="card">

<h3>Active Students</h3>

<h2 class="active">

<?php echo $activeStudent['active']; ?>

</h2>

</div>

<div class="card">

<h3>Inactive Students</h3>

<h2 class="inactive">

<?php echo $inactiveStudent['inactive']; ?>

</h2>

</div>

</div>

<div class="content">

<table>

<tr>

<th>ID</th>

<th>Photo</th>

<th>Student Name</th>

<th>Father Name</th>

<th>Mobile</th>

<th>Email</th>

<th>Course</th>

<th>Aadhaar</th>

<th>Register Date</th>

<th>Status</th>

<th>Action</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td>

<?php echo $row['id']; ?>

</td>

<td>

<?php

if(!empty($row['ProfilePhoto']))
{

?>

<img src="uploads/<?php echo $row['ProfilePhoto']; ?>"

style="width:70px;
height:70px;
border-radius:50%;
border:2px solid #0d6efd;
object-fit:cover;">

<?php

}
else
{

echo "No Photo";

}

?>

</td>

<td>

<?php echo $row['StudentName']; ?>

</td>

<td>

<?php echo $row['FatherName']; ?>

</td>

<td>

<?php echo $row['MobileNumber']; ?>

</td>

<td>

<?php echo $row['EmailAddress']; ?>

</td>

<td>

<?php echo $row['Course']; ?>

</td>

<td>

<?php echo $row['AadhaarNumber']; ?>

</td>

<td>

<?php echo $row['RegisterDate']; ?>

</td>

<td>

<?php

if($row['Status']=="Active")
{

echo "<span style='background:green;color:white;padding:5px 10px;border-radius:20px;'>Active</span>";

}
else
{

echo "<span style='background:red;color:white;padding:5px 10px;border-radius:20px;'>Inactive</span>";

}

?>

</td>

<td>

<a href="edit.php?id=<?php echo $row['id']; ?>"
style="
background:#198754;
color:white;
padding:6px 12px;
text-decoration:none;
border-radius:5px;
display:inline-block;
margin:2px;">
Edit
</a>

<a href="delete.php?id=<?php echo $row['id']; ?>"
onclick="return confirm('Delete this student?')"
style="
background:#dc3545;
color:white;
padding:6px 12px;
text-decoration:none;
border-radius:5px;
display:inline-block;
margin:2px;">
Delete
</a>

<a href="idcard.php?id=<?php echo $row['id']; ?>"
style="
background:#0d6efd;
color:white;
padding:6px 12px;
text-decoration:none;
border-radius:5px;
display:inline-block;
margin:2px;">
ID Card
</a>

<br><br>

<?php

if($row['Status']=="Active")
{

?>

<a href="change_status.php?id=<?php echo $row['id']; ?>&status=Inactive"
style="
background:#ffc107;
color:black;
padding:6px 12px;
text-decoration:none;
border-radius:5px;
display:inline-block;
margin:2px;">

Deactivate

</a>

<?php

}
else
{

?>

<a href="change_status.php?id=<?php echo $row['id']; ?>&status=Active"
style="
background:#198754;
color:white;
padding:6px 12px;
text-decoration:none;
border-radius:5px;
display:inline-block;
margin:2px;">

Activate

</a>

<?php

}

?>

</td>

</tr>

<?php

}

?>

</table>

</div>

<style>

table{

width:100%;

border-collapse:collapse;

background:white;

box-shadow:0 5px 15px rgba(0,0,0,.1);

border-radius:10px;

overflow:hidden;

}

table th{

background:#0d6efd;

color:white;

padding:14px;

font-size:15px;

}

table td{

padding:12px;

border-bottom:1px solid #ddd;

text-align:center;

font-size:14px;

}

table tr:hover{

background:#f1f7ff;

transition:.3s;

}

img{

transition:.3s;

}

img:hover{

transform:scale(1.1);

}

.footer{

margin-top:30px;

background:#0d6efd;

color:white;

text-align:center;

padding:15px;

font-size:15px;

}

@media(max-width:992px){

.dashboard{

grid-template-columns:repeat(2,1fr);

}

.menu{

text-align:center;

}

.menu a{

display:block;

margin:8px auto;

width:220px;

}

}

@media(max-width:768px){

.dashboard{

grid-template-columns:1fr;

}

.header{

flex-direction:column;

gap:10px;

text-align:center;

}

table{

display:block;

overflow-x:auto;

white-space:nowrap;

}

}

</style>

<div class="footer">

<h3>IICT COMPUTER CENTER</h3>

<p>

89/77/2, Chaddha Road,

Malviyanagar,

Prayagraj - 211003

</p>

<p>

📞 +91 XXXXX XXXXX |

📧 info@iictcomputercenter.com

</p>

<p>

© 2026 IICT Computer Center

All Rights Reserved.

</p>

</div>

</body>

</html>