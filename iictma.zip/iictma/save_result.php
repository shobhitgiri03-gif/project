<?php

include("db.php");

if(isset($_POST['save']))
{

    $StudentID = $_POST['StudentID'];
    $Course = $_POST['Course'];
    $Subject = $_POST['Subject'];
    $TotalMarks = $_POST['TotalMarks'];
    $ObtainedMarks = $_POST['ObtainedMarks'];
    $ResultDate = $_POST['ResultDate'];

    // Percentage Calculate
    $Percentage = ($ObtainedMarks / $TotalMarks) * 100;

    // Grade Calculate
    if($Percentage >= 90)
    {
        $Grade = "A+";
    }
    elseif($Percentage >= 80)
    {
        $Grade = "A";
    }
    elseif($Percentage >= 70)
    {
        $Grade = "B";
    }
    elseif($Percentage >= 60)
    {
        $Grade = "C";
    }
    elseif($Percentage >= 40)
    {
        $Grade = "D";
    }
    else
    {
        $Grade = "FAIL";
    }

    $sql = "INSERT INTO result
    (StudentID, Course, Subject, TotalMarks, ObtainedMarks, Percentage, Grade, ResultDate)
    VALUES
    ('$StudentID','$Course','$Subject','$TotalMarks','$ObtainedMarks','$Percentage','$Grade','$ResultDate')";

    if(mysqli_query($conn,$sql))
    {

        // Student Name Fetch
        $student = mysqli_query($conn,"SELECT StudentName FROM iicttv WHERE id='$StudentID'");
        $data = mysqli_fetch_assoc($student);

        $StudentName = $data['StudentName'];

        // Activity Log
        $date = date("Y-m-d H:i:s");

        mysqli_query($conn,"
        INSERT INTO activity_log
        (StudentName,Activity,ActivityDate)
        VALUES
        ('$StudentName','Result Added','$date')
        ");

        echo "<script>

        alert('Result Saved Successfully');

        window.location='result_report.php';

        </script>";

    }
    else
    {

        echo mysqli_error($conn);

    }

}

?>