<?php

include("db.php");

$backup_file = "backup_".date("Y-m-d_H-i-s").".sql";

header("Content-Type: application/octet-stream");

header("Content-Disposition: attachment; filename=$backup_file");

$tables = mysqli_query($conn,"SHOW TABLES");

while($table=mysqli_fetch_array($tables))
{

    $table_name = $table[0];

    $result = mysqli_query($conn,"SELECT * FROM $table_name");

    while($row=mysqli_fetch_assoc($result))
    {

        echo "-- ".$table_name."\n";

        echo json_encode($row);

        echo "\n\n";

    }

}

?>