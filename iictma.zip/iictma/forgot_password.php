<?php

include("db.php");

if(isset($_POST['reset']))
{

    $EmailAddress = $_POST['EmailAddress'];
    $NewPassword = $_POST['NewPassword'];

    $sql = "UPDATE iicttv
    SET CreatePassword='$NewPassword'
    WHERE EmailAddress='$EmailAddress'";

    if(mysqli_query($conn,$sql))
    {

        if(mysqli_affected_rows($conn)>0)
        {

            echo "<script>

            alert('Password Updated Successfully');

            window.location='login.html';

            </script>";

        }
        else
        {

            echo "<script>

            alert('Email Not Found');

            window.location='forgot_password.html';

            </script>";

        }

    }
    else
    {

        echo mysqli_error($conn);

    }

}

?>