<?php

include("db.php");

$id = $_GET['id'];

$sql = "SELECT * FROM iicttv WHERE id='$id'";

$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Course Certificate</title>

<style>

body{
font-family:"Times New Roman";
background:#f5f5f5;
}

.certificate{

width:900px;

margin:30px auto;

background:white;

border:10px solid #0d6efd;

padding:50px;

text-align:center;

}

.logo{

font-size:40px;

font-weight:bold;

color:#0d6efd;

}

.name{

font-size:35px;

font-weight:bold;

margin:20px 0;

color:red;

}

.course{

font-size:28px;

color:green;

}

.footer{

margin-top:80px;

display:flex;

justify-content:space-between;

}

button{

padding:10px 25px;

background:#0d6efd;

color:white;

border:none;

cursor:pointer;

margin-top:30px;

}

</style>

</head>

<body>

<div class="certificate">

<div class="logo">

IICT COMPUTER CLASSES

</div>

<h1>

CERTIFICATE OF COMPLETION

</h1>

<p>

This is to certify that

</p>

<div class="name">

<?php echo $row['StudentName']; ?>

</div>

<p>

has successfully completed

</p>

<div class="course">

<?php echo $row['Course']; ?>

</div>

<p>

with excellent performance.

</p>

<div class="footer">

<div>

_____________________

<br>

Director

</div>

<div>

_____________________

<br>

Student Signature

</div>

</div>

<button onclick="window.print()">

Print Certificate

</button>

</div>

</body>

</html>