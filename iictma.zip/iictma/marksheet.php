<?php

include("db.php");

$id = $_GET['id'];

$sql = "SELECT result.*, iicttv.StudentName
FROM result
INNER JOIN iicttv
ON result.StudentID=iicttv.id
WHERE ResultID='$id'";

$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Marksheet</title>

<style>

body{

font-family:Arial;

background:#f5f5f5;

}

.marksheet{

width:800px;

margin:30px auto;

background:white;

padding:30px;

border:5px solid #0d6efd;

}

h1{

text-align:center;

color:#0d6efd;

}

table{

width:100%;

border-collapse:collapse;

margin-top:20px;

}

table td{

border:1px solid #000;

padding:10px;

}

button{

margin-top:20px;

padding:10px 20px;

background:#0d6efd;

color:white;

border:none;

cursor:pointer;

}

@media print{

button{

display:none;

}

}

</style>

</head>

<body>

<div class="marksheet">

<h1>

IICT COMPUTER CLASSES

</h1>

<h2 align="center">

Student Marksheet

</h2>

<table>

<tr>

<td><b>Student Name</b></td>

<td><?php echo $row['StudentName']; ?></td>

</tr>

<tr>

<td><b>Course</b></td>

<td><?php echo $row['Course']; ?></td>

</tr>

<tr>

<td><b>Subject</b></td>

<td><?php echo $row['Subject']; ?></td>

</tr>

<tr>

<td><b>Total Marks</b></td>

<td><?php echo $row['TotalMarks']; ?></td>

</tr>

<tr>

<td><b>Obtained Marks</b></td>

<td><?php echo $row['ObtainedMarks']; ?></td>

</tr>

<tr>

<td><b>Percentage</b></td>

<td><?php echo number_format($row['Percentage'],2); ?>%</td>

</tr>

<tr>

<td><b>Grade</b></td>

<td><?php echo $row['Grade']; ?></td>

</tr>

<tr>

<td><b>Result Date</b></td>

<td><?php echo $row['ResultDate']; ?></td>

</tr>

</table>

<center>

<button onclick="window.print()">

Print Marksheet

</button>

</center>

</div>

</body>

</html>