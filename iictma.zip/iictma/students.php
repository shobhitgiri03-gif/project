<?php
session_start();

if(!isset($_SESSION['admin']))
{
header("Location:admin_login.html");
exit();
}

include("db.php");

$result=mysqli_query($conn,"SELECT * FROM iicttv ORDER BY StudentName ASC");

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Students Management</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{
background:#f4f6f9;
font-family:Arial;
}

.container{
width:95%;
margin:30px auto;
}

table{
width:100%;
border-collapse:collapse;
background:white;
box-shadow:0 0 10px rgba(0,0,0,.15);
}

table th{
background:#0d6efd;
color:white;
padding:12px;
}

table td{
padding:10px;
border:1px solid #ddd;
text-align:center;
}

img{
width:60px;
height:60px;
border-radius:50%;
object-fit:cover;
}

.btn{
padding:8px 15px;
text-decoration:none;
color:white;
border-radius:5px;
}

.edit{
background:#198754;
}

.delete{
background:#dc3545;
}

.search{
margin-bottom:20px;
}

.search input{
width:300px;
padding:10px;
}

</style>

</head>

<body>

<div class="container">

<h2>Students Management</h2>

<div class="search">

<input
type="text"
id="myInput"
placeholder="Search Student..."
onkeyup="searchStudent()">

</div>

<table id="studentTable">

<tr>

<th>Photo</th>

<th>Name</th>

<th>Father</th>

<th>Mobile</th>

<th>Email</th>

<th>Course</th>

<th>Action</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td>

<img src="uploads/<?php echo $row['ProfilePhoto'];?>">

</td>

<td><?php echo $row['StudentName'];?></td>

<td><?php echo $row['FatherName'];?></td>

<td><?php echo $row['MobileNumber'];?></td>

<td><?php echo $row['EmailAddress'];?></td>

<td><?php echo $row['Course'];?></td>

<td>

<a class="btn edit"
href="edit_student.php?id=<?php echo $row['ID'];?>">

Edit

</a>

<a class="btn delete"
href="delete_student.php?id=<?php echo $row['ID'];?>"
onclick="return confirm('Delete Student?')">

Delete

</a>

</td>

</tr>

<?php

}

?>

</table>

</div>

<script>

function searchStudent(){

var input=document.getElementById("myInput");

var filter=input.value.toUpperCase();

var table=document.getElementById("studentTable");

var tr=table.getElementsByTagName("tr");

for(var i=1;i<tr.length;i++){

var td=tr[i].getElementsByTagName("td")[1];

if(td){

txt=td.textContent||td.innerText;

tr[i].style.display=txt.toUpperCase().indexOf(filter)>-1?"":"none";

}

}

}

</script>

</body>

</html>