<?php

include("db.php");

$total = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) AS total FROM iicttv"));

$today = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) AS today FROM iicttv
WHERE DATE(RegisterDate)=CURDATE()"));

$month = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) AS month FROM iicttv
WHERE MONTH(RegisterDate)=MONTH(CURDATE())
AND YEAR(RegisterDate)=YEAR(CURDATE())"));

$year = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) AS year FROM iicttv
WHERE YEAR(RegisterDate)=YEAR(CURDATE())"));

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Admission Report</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{

background:#f5f5f5;

font-family:Arial;

}

.container{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

padding:30px;

}

.card{

background:white;

padding:25px;

border-radius:12px;

text-align:center;

box-shadow:0 5px 15px rgba(0,0,0,.1);

}

.card h2{

color:#0d6efd;

font-size:35px;

margin-top:10px;

}

</style>

</head>

<body>

<h1 align="center">

Admission Report

</h1>

<div class="container">

<div class="card">

<h3>Total Students</h3>

<h2>

<?php echo $total['total']; ?>

</h2>

</div>

<div class="card">

<h3>Today's Admission</h3>

<h2>

<?php echo $today['today']; ?>

</h2>

</div>

<div class="card">

<h3>This Month</h3>

<h2>

<?php echo $month['month']; ?>

</h2>

</div>

<div class="card">

<h3>This Year</h3>

<h2>

<?php echo $year['year']; ?>

</h2>

</div>

</div>

</body>

</html>