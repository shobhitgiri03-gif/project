<?php

include("db.php");

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Student_Report.xls");

echo "ID\tStudent Name\tFather Name\tMobile\tEmail\tCourse\n";

$sql = "SELECT * FROM iicttv";

$result = mysqli_query($conn,$sql);

while($row = mysqli_fetch_assoc($result))
{

echo $row['id']."\t";

echo $row['StudentName']."\t";

echo $row['FatherName']."\t";

echo $row['MobileNumber']."\t";

echo $row['EmailAddress']."\t";

echo $row['Course']."\n";

}

?>