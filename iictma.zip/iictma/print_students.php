<?php

include("db.php");

$sql = "SELECT * FROM iicttv";

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Report</title>

<style>

body{

font-family:Arial;

}

h1{

text-align:center;

}

table{

width:100%;

border-collapse:collapse;

}

table th,
table td{

border:1px solid black;

padding:8px;

text-align:center;

}

table th{

background:#ddd;

}

button{

padding:10px 20px;

margin:20px;

}

@media print{

button{

display:none;

}

}

</style>

</head>

<body>

<button onclick="window.print()">

Print / Save PDF

</button>

<h1>IICT COMPUTER CLASSES</h1>

<h2 align="center">

Student Report

</h2>

<table>

<tr>

<th>ID</th>
<th>Name</th>
<th>Father Name</th>
<th>Mobile</th>
<th>Email</th>
<th>Course</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['id']; ?></td>
<td><?php echo $row['StudentName']; ?></td>
<td><?php echo $row['FatherName']; ?></td>
<td><?php echo $row['MobileNumber']; ?></td>
<td><?php echo $row['EmailAddress']; ?></td>
<td><?php echo $row['Course']; ?></td>

</tr>

<?php

}

?>

</table>

</body>

</html>