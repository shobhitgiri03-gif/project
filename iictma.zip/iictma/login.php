<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

include("db.php");

if(isset($_POST['login']))
{

    $email = trim($_POST['EmailAddress']);
    $password = trim($_POST['CreatePassword']);

    $sql = "SELECT * FROM iicttv WHERE EmailAddress='$email'";

    $result = mysqli_query($conn,$sql);

    if(!$result)
    {
        die("SQL Error : ".mysqli_error($conn));
    }

    if(mysqli_num_rows($result)==1)
    {

        $row = mysqli_fetch_assoc($result);

        if($password == $row['CreatePassword'])
        {

            $_SESSION['StudentName'] = $row['StudentName'];
            $_SESSION['EmailAddress'] = $row['EmailAddress'];
            $_SESSION['Course'] = $row['Course'];

            // Activity Log
            $StudentName = $row['StudentName'];
            $date = date("Y-m-d H:i:s");

            mysqli_query($conn,"
            INSERT INTO activity_log
            (StudentName,Activity,ActivityDate)
            VALUES
            ('$StudentName','Student Login','$date')
            ");

            header("Location: dashboard.php");
            exit();

        }
        else
        {

            echo "<script>
            alert('Wrong Password');
            window.location='login.html';
            </script>";

        }

    }
    else
    {

        echo "<script>
        alert('Email Not Registered');
        window.location='login.html';
        </script>";

    }

}
else
{

    echo "Invalid Request";

}

?>