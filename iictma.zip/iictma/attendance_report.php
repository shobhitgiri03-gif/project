<?php

include("db.php");

$sql = "SELECT attendance.*, iicttv.StudentName
FROM attendance
INNER JOIN iicttv
ON attendance.StudentID=iicttv.id
ORDER BY AttendanceDate DESC";

$result=mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Attendance Report</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{

font-family:Arial;

background:#f5f5f5;

margin:20px;

}

table{

width:100%;

border-collapse:collapse;

background:white;

}

table th,
table td{

border:1px solid #ddd;

padding:10px;

text-align:center;

}

table th{

background:#0d6efd;

color:white;

}

.present{

background:green;

color:white;

padding:5px 12px;

border-radius:5px;

}

.absent{

background:red;

color:white;

padding:5px 12px;

border-radius:5px;

}

</style>

</head>

<body>

<h2 align="center">

Attendance Report

</h2>

<table>

<tr>

<th>ID</th>

<th>Student Name</th>

<th>Date</th>

<th>Status</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['AttendanceID']; ?></td>

<td><?php echo $row['StudentName']; ?></td>

<td><?php echo $row['AttendanceDate']; ?></td>

<td>

<?php

if($row['Status']=="Present")
{

echo "<span class='present'>Present</span>";

}
else
{

echo "<span class='absent'>Absent</span>";

}

?>

</td>

</tr>

<?php

}

?>

</table>

</body>

</html>