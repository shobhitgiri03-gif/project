<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

$id=$_GET['id'];

$result=mysqli_query($conn,"SELECT * FROM iicttv WHERE ID='$id'");

$row=mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Profile</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{
background:#f4f6f9;
font-family:Arial;
}

.container{
width:850px;
margin:30px auto;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,.2);
}

.photo{
width:170px;
height:170px;
border-radius:50%;
border:5px solid #0d6efd;
object-fit:cover;
}

table{
width:100%;
margin-top:30px;
border-collapse:collapse;
}

table td{
border:1px solid #ddd;
padding:12px;
}

.title{
background:#0d6efd;
color:white;
font-weight:bold;
width:35%;
}

.btn{
display:inline-block;
padding:10px 20px;
background:#0d6efd;
color:white;
text-decoration:none;
border-radius:5px;
margin:10px;
}

.btn:hover{
background:#084298;
}

</style>

</head>

<body>

<div class="container">

<center>

<img src="uploads/<?php echo $row['ProfilePhoto']; ?>" class="photo">

<h2><?php echo $row['StudentName']; ?></h2>

</center>

<table>

<tr>
<td class="title">Student Name</td>
<td><?php echo $row['StudentName']; ?></td>
</tr>

<tr>
<td class="title">Father Name</td>
<td><?php echo $row['FatherName']; ?></td>
</tr>

<tr>
<td class="title">Mobile Number</td>
<td><?php echo $row['MobileNumber']; ?></td>
</tr>

<tr>
<td class="title">Email Address</td>
<td><?php echo $row['EmailAddress']; ?></td>
</tr>

<tr>
<td class="title">Aadhaar Number</td>
<td><?php echo $row['AadhaarNumber']; ?></td>
</tr>

<tr>
<td class="title">Course</td>
<td><?php echo $row['Course']; ?></td>
</tr>

<tr>
<td class="title">Address</td>
<td><?php echo $row['Address']; ?></td>
</tr>

<tr>
<td class="title">Status</td>
<td><?php echo $row['Status']; ?></td>
</tr>

<tr>
<td class="title">Registration Date</td>
<td><?php echo $row['RegisterDate']; ?></td>
</tr>

</table>

<br>

<center>

<a href="student_id_card.php?id=<?php echo $row['ID']; ?>" class="btn">

Print ID Card

</a>

<a href="students.php" class="btn">

Back

</a>

</center>

</div>

</body>

</html>