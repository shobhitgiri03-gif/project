<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

if(isset($_GET['id']))
{

$id=$_GET['id'];

$result=mysqli_query($conn,"
SELECT * FROM iicttv
WHERE ID='$id'
");

$row=mysqli_fetch_assoc($result);

if($row)
{

// Delete Photo

if($row['ProfilePhoto']!="")
{

$file="uploads/".$row['ProfilePhoto'];

if(file_exists($file))
{
unlink($file);
}

}

// Activity Log

$date=date("Y-m-d H:i:s");

mysqli_query($conn,"
INSERT INTO activity_log
(StudentName,Activity,ActivityDate)
VALUES
(
'".$row['StudentName']."',
'Student Deleted',
'$date'
)
");

// Delete Student

mysqli_query($conn,"
DELETE FROM iicttv
WHERE ID='$id'
");

echo "<script>

alert('Student Deleted Successfully');

window.location='students.php';

</script>";

}

else
{

echo "<script>

alert('Student Not Found');

window.location='students.php';

</script>";

}

}
else
{

header("Location:students.php");

}

?>