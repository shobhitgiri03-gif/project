<?php

session_start();

include("db.php");

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Feedback</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<div class="contact-box">

<h2 align="center">Student Feedback</h2>

<form action="save_feedback.php" method="POST">

<label>Name</label>

<input type="text" name="StudentName" required>

<label>Email</label>

<input type="email" name="EmailAddress" required>

<label>Subject</label>

<input type="text" name="Subject" required>

<label>Message</label>

<textarea name="Message" rows="5" required></textarea>

<br><br>

<button type="submit" name="send">

Send Feedback

</button>

</form>

</div>

</body>

</html>