<?php
include("db.php"); // सुनिश्चित करें कि आपका db.php सही से कनेक्शन बना रहा हो

$sql = "SELECT id, course_name, description, image FROM courses"; // कोर्स टेबल से डेटा
$result = mysqli_query($conn, $sql);

$courses = [];
while($row = mysqli_fetch_assoc($result)) {
    $courses[] = $row;
}

echo json_encode($courses); // JSON में रिजल्ट भेजें
?>