<?php

session_start();

include("db.php");

if(!isset($_SESSION['EmailAddress']))
{

header("Location: login.html");

exit();

}

$email=$_SESSION['EmailAddress'];

$sql="SELECT * FROM iicttv WHERE EmailAddress='$email'";

$result=mysqli_query($conn,$sql);

$row=mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>My Profile</title>

<link rel="stylesheet" href="iict00.css">

<style>

.profile{

width:700px;

margin:30px auto;

background:#fff;

padding:30px;

border-radius:15px;

box-shadow:0 10px 30px rgba(0,0,0,.15);

}

.profile img{

width:150px;

height:150px;

border-radius:50%;

display:block;

margin:auto;

border:5px solid #0d6efd;

}

table{

width:100%;

margin-top:20px;

border-collapse:collapse;

}

table td{

padding:12px;

border-bottom:1px solid #ddd;

}

h2{

text-align:center;

color:#0d6efd;

}

</style>

</head>

<body>

<div class="profile">

<h2>Student Profile</h2>

<img src="uploads/<?php echo $row['ProfilePhoto']; ?>">

<table>

<tr>

<td><b>Name</b></td>

<td><?php echo $row['StudentName']; ?></td>

</tr>

<tr>

<td><b>Father Name</b></td>

<td><?php echo $row['FatherName']; ?></td>

</tr>

<tr>

<td><b>Mobile</b></td>

<td><?php echo $row['MobileNumber']; ?></td>

</tr>

<tr>

<td><b>Email</b></td>

<td><?php echo $row['EmailAddress']; ?></td>

</tr>

<tr>

<td><b>Course</b></td>

<td><?php echo $row['Course']; ?></td>

</tr>

<tr>

<td><b>Address</b></td>

<td><?php echo $row['Address']; ?></td>

</tr>

</table>

</div>

</body>

</html>