<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

$id = $_GET['id'];

$result = mysqli_query($conn,"SELECT * FROM iicttv WHERE ID='$id'");
$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Student ID Card</title>

<style>

body{
background:#ececec;
font-family:Arial;
}

.card{

width:350px;
height:560px;
background:white;
margin:40px auto;
border-radius:15px;
overflow:hidden;
box-shadow:0 0 20px rgba(0,0,0,.3);

}

.header{

background:#0d6efd;
color:white;
text-align:center;
padding:15px;

}

.logo{

width:80px;
height:80px;
border-radius:50%;
background:white;
padding:5px;

}

.photo{

width:140px;
height:140px;
border-radius:50%;
border:4px solid #0d6efd;
object-fit:cover;
margin-top:15px;

}

.content{

padding:20px;

}

.content p{

margin:10px 0;
font-size:16px;

}

.footer{

background:#0d6efd;
color:white;
text-align:center;
padding:10px;
margin-top:20px;

}

.print{

margin-top:20px;
text-align:center;

}

button{

padding:12px 30px;
background:#198754;
color:white;
border:none;
border-radius:5px;
cursor:pointer;

}

@media print{

button{

display:none;

}

body{

background:white;

}

}

</style>

</head>

<body>

<div class="card">

<div class="header">

<img src="images/logo.png" class="logo">

<h2>IICT Computer Classes</h2>

<h4>Student Identity Card</h4>

</div>

<center>

<img src="uploads/<?php echo $row['ProfilePhoto']; ?>" class="photo">

</center>

<div class="content">

<p><b>ID :</b> IICT<?php echo $row['ID']; ?></p>

<p><b>Name :</b> <?php echo $row['StudentName']; ?></p>

<p><b>Course :</b> <?php echo $row['Course']; ?></p>

<p><b>Mobile :</b> <?php echo $row['MobileNumber']; ?></p>

<p><b>Email :</b> <?php echo $row['EmailAddress']; ?></p>

</div>

<div class="footer">

Authorized By IICT

</div>

</div>

<div class="print">

<button onclick="window.print()">

Print ID Card

</button>

</div>

</body>

</html>