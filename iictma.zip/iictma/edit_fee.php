<?php

session_start();

if(!isset($_SESSION['admin']))
{
header("Location:admin_login.html");
exit();
}

include("db.php");

$id=$_GET['id'];

$result=mysqli_query($conn,"SELECT * FROM fees WHERE ID='$id'");

$row=mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{

$TotalFee=$_POST['TotalFee'];

$PaidFee=$_POST['PaidFee'];

mysqli_query($conn,"
UPDATE fees
SET

TotalFee='$TotalFee',
PaidFee='$PaidFee'

WHERE ID='$id'
");

echo "<script>

alert('Fee Updated Successfully');

window.location='fees.php';

</script>";

}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Edit Fee</title>

<link rel="stylesheet" href="iict00.css">

<style>

.container{

width:600px;

margin:40px auto;

background:white;

padding:30px;

border-radius:10px;

box-shadow:0 0 10px rgba(0,0,0,.2);

}

input{

width:100%;

padding:12px;

margin:10px 0;

}

button{

padding:12px 30px;

background:#198754;

color:white;

border:none;

cursor:pointer;

}

</style>

</head>

<body>

<div class="container">

<h2>Edit Fee</h2>

<form method="POST">

<label>Total Fee</label>

<input
type="number"
name="TotalFee"
value="<?php echo $row['TotalFee'];?>"
required>

<label>Paid Fee</label>

<input
type="number"
name="PaidFee"
value="<?php echo $row['PaidFee'];?>"
required>

<button
type="submit"
name="update">

Update Fee

</button>

</form>

</div>

</body>

</html>