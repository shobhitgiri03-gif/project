<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

$id=$_GET['id'];

$result=mysqli_query($conn,"SELECT * FROM iicttv WHERE ID='$id'");

$row=mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{

$StudentName=$_POST['StudentName'];
$FatherName=$_POST['FatherName'];
$MobileNumber=$_POST['MobileNumber'];
$EmailAddress=$_POST['EmailAddress'];
$AadhaarNumber=$_POST['AadhaarNumber'];
$Course=$_POST['Course'];
$Address=$_POST['Address'];
$Status=$_POST['Status'];

if($_FILES['ProfilePhoto']['name']!="")
{

$ProfilePhoto=$_FILES['ProfilePhoto']['name'];

$temp=$_FILES['ProfilePhoto']['tmp_name'];

move_uploaded_file($temp,"uploads/".$ProfilePhoto);

mysqli_query($conn,"
UPDATE iicttv
SET ProfilePhoto='$ProfilePhoto'
WHERE ID='$id'
");

}

mysqli_query($conn,"
UPDATE iicttv
SET

StudentName='$StudentName',
FatherName='$FatherName',
MobileNumber='$MobileNumber',
EmailAddress='$EmailAddress',
AadhaarNumber='$AadhaarNumber',
Course='$Course',
Address='$Address',
Status='$Status'

WHERE ID='$id'
");

echo "<script>

alert('Student Updated Successfully');

window.location='students.php';

</script>";

}

?>

<!DOCTYPE html>

<html>

<head>

<title>Edit Student</title>

<link rel="stylesheet" href="iict00.css">

<style>

.container{

width:700px;
margin:30px auto;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,.2);

}

input,select,textarea{

width:100%;
padding:12px;
margin:10px 0;

}

button{

background:#198754;
color:white;
padding:12px 25px;
border:none;
cursor:pointer;

}

img{

width:120px;
height:120px;
border-radius:50%;
object-fit:cover;

}

</style>

</head>

<body>

<div class="container">

<h2>Edit Student</h2>

<form method="POST" enctype="multipart/form-data">

<center>

<img src="uploads/<?php echo $row['ProfilePhoto'];?>">

</center>

<input type="text"
name="StudentName"
value="<?php echo $row['StudentName'];?>">

<input type="text"
name="FatherName"
value="<?php echo $row['FatherName'];?>">

<input type="text"
name="MobileNumber"
value="<?php echo $row['MobileNumber'];?>">

<input type="email"
name="EmailAddress"
value="<?php echo $row['EmailAddress'];?>">

<input type="text"
name="AadhaarNumber"
value="<?php echo $row['AadhaarNumber'];?>">

<select name="Course">

<option><?php echo $row['Course'];?></option>

<option>ADCA</option>
<option>DCA</option>
<option>CCA</option>
<option>CCC</option>
<option>JAVA</option>
<option>PYTHON</option>
<option>TALLY</option>

</select>

<textarea
name="Address"><?php echo $row['Address'];?></textarea>

<select name="Status">

<option><?php echo $row['Status'];?></option>

<option>Active</option>

<option>Inactive</option>

</select>

<label>Change Photo</label>

<input
type="file"
name="ProfilePhoto">

<br><br>

<button
type="submit"
name="update">

Update Student

</button>

</form>

</div>

</body>

</html>