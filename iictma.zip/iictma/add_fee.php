<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

if(isset($_POST['save']))
{

$StudentID=$_POST['StudentID'];
$TotalFee=$_POST['TotalFee'];
$PaidFee=$_POST['PaidFee'];

$ReceiptNo="IICT".date("YmdHis");

$FeeDate=date("Y-m-d");

mysqli_query($conn,"
INSERT INTO fees
(
StudentID,
ReceiptNo,
TotalFee,
PaidFee,
FeeDate
)
VALUES
(
'$StudentID',
'$ReceiptNo',
'$TotalFee',
'$PaidFee',
'$FeeDate'
)
");

echo "<script>

alert('Fee Collected Successfully');

window.location='fees.php';

</script>";

}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Collect Fee</title>

<link rel="stylesheet" href="iict00.css">

<style>

.container{

width:600px;
margin:40px auto;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,.2);

}

input,select{

width:100%;
padding:12px;
margin:10px 0;

}

button{

padding:12px 30px;
background:#198754;
color:white;
border:none;
cursor:pointer;
border-radius:5px;

}

</style>

</head>

<body>

<div class="container">

<h2>Collect Student Fee</h2>

<form method="POST">

<label>Select Student</label>

<select name="StudentID" required>

<option value="">Select Student</option>

<?php

$result=mysqli_query($conn,"
SELECT ID,StudentName
FROM iicttv
ORDER BY StudentName
");

while($row=mysqli_fetch_assoc($result))
{

?>

<option value="<?php echo $row['ID']; ?>">

<?php echo $row['StudentName']; ?>

</option>

<?php

}

?>

</select>

<input
type="number"
name="TotalFee"
placeholder="Total Fee"
required>

<input
type="number"
name="PaidFee"
placeholder="Paid Fee"
required>

<button
type="submit"
name="save">

Save Fee

</button>

</form>

</div>

</body>

</html>