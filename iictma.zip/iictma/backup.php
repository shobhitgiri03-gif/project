<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "IICT";

$conn = new mysqli($host,$user,$pass,$db);

header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=IICT_Backup.sql");

$tables = mysqli_query($conn,"SHOW TABLES");

while($table=mysqli_fetch_array($tables))
{

$table_name = $table[0];

$result = mysqli_query($conn,"SELECT * FROM $table_name");

echo "DROP TABLE IF EXISTS $table_name;\n";

$row2 = mysqli_fetch_row(mysqli_query($conn,"SHOW CREATE TABLE $table_name"));

echo $row2[1].";\n\n";

while($row=mysqli_fetch_assoc($result))
{

$values=array();

foreach($row as $value)
{

$values[]="'".addslashes($value)."'";

}

echo "INSERT INTO $table_name VALUES(".implode(",",$values).");\n";

}

echo "\n\n";

}

?>