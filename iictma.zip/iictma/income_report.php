<?php

include("db.php");

$total = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT SUM(PaidFee) AS total FROM fees"));

$today = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT SUM(PaidFee) AS today FROM fees
WHERE DATE(PaymentDate)=CURDATE()"));

$month = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT SUM(PaidFee) AS month FROM fees
WHERE MONTH(PaymentDate)=MONTH(CURDATE())
AND YEAR(PaymentDate)=YEAR(CURDATE())"));

$year = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT SUM(PaidFee) AS year FROM fees
WHERE YEAR(PaymentDate)=YEAR(CURDATE())"));

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Income Report</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{
font-family:Arial;
background:#f4f7fc;
}

.container{
display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
padding:30px;
}

.card{
background:white;
padding:25px;
border-radius:12px;
box-shadow:0 5px 15px rgba(0,0,0,.1);
text-align:center;
}

.card h2{
font-size:35px;
color:#198754;
margin-top:10px;
}

</style>

</head>

<body>

<h1 align="center">

Income Report

</h1>

<div class="container">

<div class="card">

<h3>Total Income</h3>

<h2>

₹<?php echo $total['total'] ?? 0; ?>

</h2>

</div>

<div class="card">

<h3>Today's Income</h3>

<h2>

₹<?php echo $today['today'] ?? 0; ?>

</h2>

</div>

<div class="card">

<h3>This Month</h3>

<h2>

₹<?php echo $month['month'] ?? 0; ?>

</h2>

</div>

<div class="card">

<h3>This Year</h3>

<h2>

₹<?php echo $year['year'] ?? 0; ?>

</h2>

</div>

</div>

</body>

</html>