<?php

include("db.php");

$id = $_GET['id'];

$sql = "SELECT * FROM iicttv WHERE id='$id'";

$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{

$StudentName = $_POST['StudentName'];
$FatherName = $_POST['FatherName'];
$MobileNumber = $_POST['MobileNumber'];
$EmailAddress = $_POST['EmailAddress'];
$Course = $_POST['Course'];

$update = "UPDATE iicttv SET

StudentName='$StudentName',
FatherName='$FatherName',
MobileNumber='$MobileNumber',
EmailAddress='$EmailAddress',
Course='$Course'

WHERE id='$id'";

if(mysqli_query($conn,$update))
{

echo "<script>

alert('Student Updated Successfully');

window.location='admin.php';

</script>";

}
else
{

echo mysqli_error($conn);

}

}

?>

<!DOCTYPE html>

<html>

<head>

<title>Edit Student</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<h2>Edit Student</h2>

<form method="POST">

<label>Student Name</label>

<input type="text"
name="StudentName"
value="<?php echo $row['StudentName']; ?>">

<label>Father Name</label>

<input type="text"
name="FatherName"
value="<?php echo $row['FatherName']; ?>">

<label>Mobile Number</label>

<input type="text"
name="MobileNumber"
value="<?php echo $row['MobileNumber']; ?>">

<label>Email</label>

<input type="email"
name="EmailAddress"
value="<?php echo $row['EmailAddress']; ?>">

<label>Course</label>

<input type="text"
name="Course"
value="<?php echo $row['Course']; ?>">

<br><br>

<button type="submit" name="update">
Update Student
</button>

</form>

</body>

</html>