<?php

include("db.php");

?>

<!DOCTYPE html>

<html>

<head>

<title>Search Student</title>

<link rel="stylesheet" href="iict00.css">

<style>

table{

width:100%;

border-collapse:collapse;

margin-top:20px;

}

table,th,td{

border:1px solid black;

padding:10px;

text-align:center;

}

th{

background:#0d6efd;

color:white;

}

</style>

</head>

<body>

<h2 align="center">Search Student</h2>

<form method="GET" align="center">

<input type="text"
name="search"
placeholder="Enter Name / Mobile / Email"
required>

<button type="submit">

Search

</button>

</form>

<br>

<?php

if(isset($_GET['search']))
{

$search=$_GET['search'];

$sql="SELECT * FROM iicttv

WHERE StudentName LIKE '%$search%'

OR MobileNumber LIKE '%$search%'

OR EmailAddress LIKE '%$search%'";

$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0)
{

?>

<table>

<tr>

<th>ID</th>

<th>Name</th>

<th>Father Name</th>

<th>Mobile</th>

<th>Email</th>

<th>Course</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['StudentName']; ?></td>

<td><?php echo $row['FatherName']; ?></td>

<td><?php echo $row['MobileNumber']; ?></td>

<td><?php echo $row['EmailAddress']; ?></td>

<td><?php echo $row['Course']; ?></td>

</tr>

<?php

}

?>

</table>

<?php

}
else
{

echo "<h3 align='center'>No Student Found</h3>";

}

}

?>

</body>

</html>