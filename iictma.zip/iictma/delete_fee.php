<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

if(isset($_GET['id']))
{

$id=$_GET['id'];

// Fee Details

$result=mysqli_query($conn,"
SELECT
fees.*,
iicttv.StudentName
FROM fees
INNER JOIN iicttv
ON fees.StudentID=iicttv.ID
WHERE fees.ID='$id'
");

$row=mysqli_fetch_assoc($result);

// Activity Log

$date=date("Y-m-d H:i:s");

mysqli_query($conn,"
INSERT INTO activity_log
(
StudentName,
Activity,
ActivityDate
)
VALUES
(
'".$row['StudentName']."',
'Fee Record Deleted',
'$date'
)
");

// Delete Fee

mysqli_query($conn,"
DELETE FROM fees
WHERE ID='$id'
");

echo "<script>

alert('Fee Record Deleted Successfully');

window.location='fees.php';

</script>";

}

else
{

header("Location:fees.php");

}

?>