<?php

session_start();

include("db.php");

$sql = "SELECT * FROM feedback ORDER BY FeedbackID DESC";

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Feedback Report</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{

font-family:Arial;

background:#f5f5f5;

margin:20px;

}

table{

width:100%;

border-collapse:collapse;

background:white;

box-shadow:0 5px 15px rgba(0,0,0,.1);

}

table th,
table td{

border:1px solid #ddd;

padding:10px;

text-align:center;

}

table th{

background:#0d6efd;

color:white;

}

.delete{

background:red;

color:white;

padding:6px 12px;

text-decoration:none;

border-radius:5px;

}

</style>

</head>

<body>

<h2 align="center">

Student Feedback Report

</h2>

<table>

<tr>

<th>ID</th>

<th>Name</th>

<th>Email</th>

<th>Subject</th>

<th>Message</th>

<th>Date</th>

<th>Action</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['FeedbackID']; ?></td>

<td><?php echo $row['StudentName']; ?></td>

<td><?php echo $row['EmailAddress']; ?></td>

<td><?php echo $row['Subject']; ?></td>

<td><?php echo $row['Message']; ?></td>

<td><?php echo $row['FeedbackDate']; ?></td>

<td>

<a class="delete"

href="delete_feedback.php?id=<?php echo $row['FeedbackID']; ?>"

onclick="return confirm('Delete this feedback?')">

Delete

</a>

</td>

</tr>

<?php

}

?>

</table>

</body>

</html>