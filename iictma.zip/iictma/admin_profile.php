<?php
session_start();
include("db.php");

// एडमिन सत्र की जाँच करें
if (!isset($_SESSION['admin'])) {
    echo "Login First";
    exit();
}

// एडमिन की जानकारी लोड करें
$admin_email = $_SESSION['admin']; // यह तुम्हारा सत्र होगा
$sql = "SELECT * FROM admins WHERE email='$admin_email'";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) == 1) {
    $admin = mysqli_fetch_assoc($result);
} else {
    echo "Admin not found";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            text-align: center;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        .title {
            font-weight: bold;
            background: #0d6efd;
            color: white;
            width: 35%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Profile</h2>
        <table>
            <tr>
                <td class="title">Admin Name</td>
                <td><?php echo htmlspecialchars($admin['name']); ?></td>
            </tr>
            <tr>
                <td class="title">Email</td>
                <td><?php echo htmlspecialchars($admin['email']); ?></td>
            </tr>
            <tr>
                <td class="title">Joined On</td>
                <td><?php echo htmlspecialchars($admin['joined_date']); ?></td>
            </tr>
            <!-- और भी जानकारी जोड़ सकते हो -->
        </table>
    </div>
</body>
</html>