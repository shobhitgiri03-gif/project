/* =================================
   IICT Computer Classes
   Main JavaScript File
================================= */


/* ===============================
   Login System
================================ */


function loginUser(){

    let username = document.getElementById("username").value;

    let password = document.getElementById("password").value;


    if(username === "admin" && password === "12345"){

        alert("Login Successful Welcome to IICT");

        window.location.href = "dashboard.html";

    }

    else{

        alert("Wrong Email / Password");

    }

}




/* ===============================
   Registration Form
================================ */


function registerUser(){

    let name = document.getElementById("name").value;

    let mobile = document.getElementById("mobile").value;


    if(name === "" || mobile === ""){

        alert("Please Fill All Required Details");

        return false;

    }


    alert("Registration Successful");

    return true;

}


function searchWebsite(){

let search=document.getElementById("searchInput").value.toLowerCase();

if(search=="home"){

window.location.href="index.html";

}

else if(search=="about"){

window.location.href="about.html";

}

else if(search=="courses"){

window.location.href="courses.html";

}

else if(search=="gallery"){

window.location.href="gallery.html";

}

else if(search=="contact"){

window.location.href="contact.html";

}

else if(search=="login"){

window.location.href="login.html";

}

else if(search=="register"){

window.location.href="register.html";

}

else{

alert("No Page Found");

}

}





/* ===============================
   Contact Form
================================ */


function contactForm(){

    alert("Your Message Has Been Sent Successfully");

}






/* ===============================
   Password Show Hide
================================ */


function showPassword(){

    let pass = document.getElementById("password");


    if(pass.type === "password"){

        pass.type = "text";

    }

    else{

        pass.type = "password";

    }

}






/* ===============================
   Mobile Menu
================================ */


function menuToggle(){

    let menu = document.querySelector("nav ul");


    menu.classList.toggle("active");

}






/* ===============================
   Page Loading Message
================================ */


window.onload = function(){

    console.log("IICT Computer Classes Website Loaded Successfully");

};






/* ===============================
   Smooth Scroll
================================ */


document.querySelectorAll('a[href^="#"]').forEach(anchor => {


    anchor.addEventListener('click', function(e){


        e.preventDefault();


        document.querySelector(this.getAttribute('href'))
        .scrollIntoView({

            behavior:'smooth'

        });


    });


});





function updateCourseInfo(){

var course=document.getElementsByName("Course")[0].value;

var duration=document.getElementById("duration");

var fees=document.getElementById("fees");

switch(course){

case "ADCA":
duration.value="12 Months";
fees.value="₹12,000";
break;

case "DCA":
duration.value="6 Months";
fees.value="₹6,000";
break;

case "CCA":
duration.value="3 Months";
fees.value="₹3,500";
break;

case "DTP":
duration.value="3 Months";
fees.value="₹4,000";
break;

case "BUSY":
duration.value="2 Months";
fees.value="₹3,000";
break;

case "TALLY":
duration.value="3 Months";
fees.value="₹5,000";
break;

case "SPOKEN ENGLISH":
duration.value="3 Months";
fees.value="₹4,000";
break;

case "CCC":
duration.value="3 Months";
fees.value="₹3,000";
break;

case "TYPING":
duration.value="3 Months";
fees.value="₹2,500";
break;

case "MS OFFICE":
duration.value="2 Months";
fees.value="₹3,000";
break;

case "SHORT HAND":
duration.value="6 Months";
fees.value="₹6,000";
break;

case "WEB DESIGNING":
duration.value="6 Months";
fees.value="₹8,000";
break;

case "BLOGGING":
duration.value="2 Months";
fees.value="₹4,000";
break;

case "O LEVEL":
duration.value="12 Months";
fees.value="₹18,000";
break;

case "C":
duration.value="2 Months";
fees.value="₹3,500";
break;

case "C++":
duration.value="3 Months";
fees.value="₹4,500";
break;

case "JAVA":
duration.value="6 Months";
fees.value="₹8,000";
break;

case "PYTHON":
duration.value="6 Months";
fees.value="₹9,000";
break;

case "DIGITAL MARKETING":
duration.value="6 Months";
fees.value="₹10,000";
break;

default:
duration.value="";
fees.value="";
}

}
