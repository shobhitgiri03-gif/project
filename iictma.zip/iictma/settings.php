<?php

include("db.php");

$data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM settings LIMIT 1"));

?>

<form action="save_settings.php"
method="POST"
enctype="multipart/form-data">

<label>Institute Name</label>

<input type="text"
name="InstituteName"
value="<?php echo $data['InstituteName']; ?>">

<label>Mobile</label>

<input type="text"
name="Mobile"
value="<?php echo $data['Mobile']; ?>">

<label>Email</label>

<input type="email"
name="Email"
value="<?php echo $data['Email']; ?>">

<label>Address</label>

<textarea
name="Address"><?php echo $data['Address']; ?></textarea>

<label>Website</label>

<input type="text"
name="Website"
value="<?php echo $data['Website']; ?>">

<label>Logo</label>

<input type="file"
name="Logo">

<br><br>

<button type="submit"
name="save">

Save Settings

</button>

</form>