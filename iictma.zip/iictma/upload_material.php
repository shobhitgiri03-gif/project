<?php

include("db.php");

if(isset($_POST['upload']))
{

    $Title = $_POST['Title'];
    $Course = $_POST['Course'];

    $FileName = $_FILES['MaterialFile']['name'];
    $TempName = $_FILES['MaterialFile']['tmp_name'];

    $Folder = "materials/".$FileName;

    if(move_uploaded_file($TempName,$Folder))
    {

        $UploadDate = date("Y-m-d");

        $sql = "INSERT INTO study_material
        (Title,Course,FileName,UploadDate)
        VALUES
        ('$Title','$Course','$FileName','$UploadDate')";

        if(mysqli_query($conn,$sql))
        {

            echo "<script>

            alert('Study Material Uploaded Successfully');

            window.location='study_material_list.php';

            </script>";

        }
        else
        {

            echo mysqli_error($conn);

        }

    }
    else
    {

        echo "File Upload Failed";

    }

}

?>