<?php

include("db.php");

if(isset($_POST['register']))
{

    $StudentName    = mysqli_real_escape_string($conn,$_POST['StudentName']);
    $FatherName     = mysqli_real_escape_string($conn,$_POST['FatherName']);
    $MobileNumber   = mysqli_real_escape_string($conn,$_POST['MobileNumber']);
    $EmailAddress   = mysqli_real_escape_string($conn,$_POST['EmailAddress']);
    $AadhaarNumber  = mysqli_real_escape_string($conn,$_POST['AadhaarNumber']);
    $Course         = mysqli_real_escape_string($conn,$_POST['Course']);
    $Address        = mysqli_real_escape_string($conn,$_POST['Address']);
    $CreatePassword = mysqli_real_escape_string($conn,$_POST['CreatePassword']);

    $RegisterDate = date("Y-m-d");

    // Photo Upload
    $ProfilePhoto = "";

    if(isset($_FILES['ProfilePhoto']) && $_FILES['ProfilePhoto']['name']!="")
    {
        $ProfilePhoto = time()."_".$_FILES['ProfilePhoto']['name'];

        $temp = $_FILES['ProfilePhoto']['tmp_name'];

        $folder = "uploads/".$ProfilePhoto;

        move_uploaded_file($temp,$folder);
    }

    $sql = "INSERT INTO iicttv
    (
        StudentName,
        FatherName,
        MobileNumber,
        EmailAddress,
        AadhaarNumber,
        Course,
        Address,
        CreatePassword,
        ProfilePhoto,
        RegisterDate
    )

    VALUES
    (
        '$StudentName',
        '$FatherName',
        '$MobileNumber',
        '$EmailAddress',
        '$AadhaarNumber',
        '$Course',
        '$Address',
        '$CreatePassword',
        '$ProfilePhoto',
        '$RegisterDate'
    )";

    if(mysqli_query($conn,$sql))
    {

        $date = date("Y-m-d H:i:s");

        mysqli_query($conn,"
        INSERT INTO activity_log
        (StudentName,Activity,ActivityDate)
        VALUES
        ('$StudentName','Student Registered','$date')
        ");

        echo "<script>

        alert('Registration Successful');

        window.location='login.html';

        </script>";

    }
    else
    {

        echo "Database Error : ".mysqli_error($conn);

    }

}
else
{

    echo "Invalid Request";

}

?>