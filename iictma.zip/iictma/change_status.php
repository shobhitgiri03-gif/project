<?php

include("db.php");

$id=$_GET['id'];

$status=$_GET['status'];

mysqli_query($conn,"
UPDATE iicttv
SET Status='$status'
WHERE id='$id'
");

header("Location:admin.php");

?>