<?php
include("db.php"); // सुनिश्चित करें कि db.php कनेक्शन बना रहा है

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // इमेज अपलोड
    $image_name = time() . '_' . $_FILES['image']['name'];
    $temp_name = $_FILES['image']['tmp_name'];
    $folder = 'images/' . $image_name;

    if (move_uploaded_file($temp_name, $folder)) {
        // इमेज अपलोड सफल, अब डेटाबेस में डालें
        $sql = "INSERT INTO courses (course_name, description, image) VALUES ('$course_name', '$description', '$image_name')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Course Added Successfully'); window.location='courses.html';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Failed to upload image.";
    }
}
?>