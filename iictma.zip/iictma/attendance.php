<?php

include("db.php");

$students = mysqli_query($conn,"SELECT id,StudentName FROM iicttv");

?>

<!DOCTYPE html>

<html>

<head>

<title>Attendance</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<h2 align="center">Student Attendance</h2>

<form action="save_attendance.php" method="POST">

<label>Student</label>

<select name="StudentID" required>

<option value="">Select Student</option>

<?php

while($row=mysqli_fetch_assoc($students))
{

?>

<option value="<?php echo $row['id']; ?>">

<?php echo $row['StudentName']; ?>

</option>

<?php

}

?>

</select>

<br><br>

<label>Date</label>

<input type="date" name="AttendanceDate" required>

<br><br>

<label>Status</label>

<select name="Status">

<option value="Present">Present</option>

<option value="Absent">Absent</option>

</select>

<br><br>

<button type="submit" name="save">

Save Attendance

</button>

</form>

</body>

</html>