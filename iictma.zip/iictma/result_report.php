<?php

include("db.php");

$sql = "SELECT result.*, iicttv.StudentName
FROM result
INNER JOIN iicttv
ON result.StudentID = iicttv.id
ORDER BY ResultID DESC";

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Result Report</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{

font-family:Arial;

background:#f5f5f5;

margin:20px;

}

table{

width:100%;

border-collapse:collapse;

background:white;

}

table th,
table td{

border:1px solid #ddd;

padding:10px;

text-align:center;

}

table th{

background:#0d6efd;

color:white;

}

.pass{

background:green;

color:white;

padding:5px 10px;

border-radius:5px;

}

.fail{

background:red;

color:white;

padding:5px 10px;

border-radius:5px;

}

.btn{

background:#0d6efd;

color:white;

padding:6px 12px;

text-decoration:none;

border-radius:5px;

}

</style>

</head>

<body>

<h2 align="center">

Student Result Report

</h2>

<table>

<tr>

<th>ID</th>

<th>Student Name</th>

<th>Course</th>

<th>Subject</th>

<th>Total Marks</th>

<th>Obtained Marks</th>

<th>Percentage</th>

<th>Grade</th>

<th>Marksheet</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['ResultID']; ?></td>

<td><?php echo $row['StudentName']; ?></td>

<td><?php echo $row['Course']; ?></td>

<td><?php echo $row['Subject']; ?></td>

<td><?php echo $row['TotalMarks']; ?></td>

<td><?php echo $row['ObtainedMarks']; ?></td>

<td><?php echo number_format($row['Percentage'],2); ?>%</td>

<td>

<?php

if($row['Grade']=="FAIL")
{

echo "<span class='fail'>FAIL</span>";

}
else
{

echo "<span class='pass'>".$row['Grade']."</span>";

}

?>

</td>

<td>

<a class="btn"

href="marksheet.php?id=<?php echo $row['ResultID']; ?>">

Print

</a>

</td>

</tr>

<?php

}

?>

</table>

</body>

</html>