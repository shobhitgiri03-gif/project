<?php

include("db.php");

?>

<!DOCTYPE html>

<html>

<head>

<title>Add Notice</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<h2 align="center">Add New Notice</h2>

<form action="save_notice.php" method="POST">

<label>Notice Title</label>

<input type="text" name="Title" required>

<br><br>

<label>Description</label>

<textarea name="Description" rows="5" required></textarea>

<br><br>

<label>Date</label>

<input type="date" name="NoticeDate" required>

<br><br>

<button type="submit" name="save">

Publish Notice

</button>

</form>

</body>

</html>