<?php

include("db.php");

?>

<!DOCTYPE html>

<html>

<head>

<title>Upload Study Material</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<h2 align="center">Upload Study Material</h2>

<form action="upload_material.php" method="POST" enctype="multipart/form-data">

<label>Title</label>

<input type="text" name="Title" required>

<br><br>

<label>Course</label>

<input type="text" name="Course" required>

<br><br>

<label>Select File</label>

<input type="file" name="MaterialFile" required>

<br><br>

<button type="submit" name="upload">

Upload Material

</button>

</form>

</body>

</html>