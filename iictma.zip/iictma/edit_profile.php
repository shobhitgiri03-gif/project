<?php

session_start();

include("db.php");

if(!isset($_SESSION['EmailAddress']))
{
    header("Location: login.html");
    exit();
}

$email = $_SESSION['EmailAddress'];

if(isset($_POST['update']))
{

    $StudentName = $_POST['StudentName'];
    $FatherName = $_POST['FatherName'];
    $MobileNumber = $_POST['MobileNumber'];
    $Address = $_POST['Address'];

    $sql = "UPDATE iicttv SET
    StudentName='$StudentName',
    FatherName='$FatherName',
    MobileNumber='$MobileNumber',
    Address='$Address'
    WHERE EmailAddress='$email'";

    if(mysqli_query($conn,$sql))
    {

        echo "<script>

        alert('Profile Updated Successfully');

        window.location='profile.php';

        </script>";

    }

}

$sql = "SELECT * FROM iicttv WHERE EmailAddress='$email'";

$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Edit Profile</title>

<link rel="stylesheet" href="iict00.css">

</head>

<body>

<div class="contact-box">

<h2 align="center">

Edit Profile

</h2>

<form method="POST">

<label>Student Name</label>

<input
type="text"
name="StudentName"
value="<?php echo $row['StudentName']; ?>"
required>

<label>Father Name</label>

<input
type="text"
name="FatherName"
value="<?php echo $row['FatherName']; ?>"
required>

<label>Mobile Number</label>

<input
type="text"
name="MobileNumber"
value="<?php echo $row['MobileNumber']; ?>"
required>

<label>Address</label>

<textarea
name="Address"
required><?php echo $row['Address']; ?></textarea>

<br><br>

<button
type="submit"
name="update">

Update Profile

</button>

</form>

</div>

</body>

</html>