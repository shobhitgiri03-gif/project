<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.html");
    exit();
}
include("db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial;
            background: #f9f9f9;
            padding: 20px;
        }
        h1 {
            color: #0d6efd;
        }
        .stats {
            display: flex;
            gap: 30px;
            margin-top: 40px;
        }
        .stat-card {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            flex: 1;
            text-align: center;
        }
        .stat-card h2 {
            color: #198754;
            margin-bottom: 15px;
        }
        .stat-card p {
            font-size: 18px;
            color: #555;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: red;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <h1>Welcome, Admin</h1>
    <div class="stats">
        <div class="stat-card">
            <h2>Total Students</h2>
            <p>
                <?php
                $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM iicttv");
                $row = mysqli_fetch_assoc($result);
                echo $row['total'];
                ?>
            </p>
        </div>
        <div class="stat-card">
            <h2>Total Revenue</h2>
            <p>
                <?php
                $result = mysqli_query($conn, "SELECT SUM(PaidFee) as revenue FROM fees");
                $row = mysqli_fetch_assoc($result);
                echo isset($row['revenue']) ? "₹" . $row['revenue'] : "₹0";
                ?>
            </p>
        </div>
        <!-- और भी एडमिन स्टैट्स जोड़ सकते हैं -->
    </div>
    <br>
    <a href="admin_logout.php">Logout</a>
</body>
</html>