<?php

include("db.php");

$sql = "SELECT * FROM activity_log ORDER BY LogID DESC";

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Activity Log</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{
font-family:Arial;
background:#f4f7fc;
margin:20px;
}

table{
width:100%;
border-collapse:collapse;
background:#fff;
}

table th,
table td{
border:1px solid #ddd;
padding:12px;
text-align:center;
}

table th{
background:#0d6efd;
color:white;
}

</style>

</head>

<body>

<h2 align="center">

System Activity Log

</h2>

<table>

<tr>

<th>ID</th>

<th>Student Name</th>

<th>Activity</th>

<th>Date & Time</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['LogID']; ?></td>

<td><?php echo $row['StudentName']; ?></td>

<td><?php echo $row['Activity']; ?></td>

<td><?php echo $row['ActivityDate']; ?></td>

</tr>

<?php

}

?>

</table>

</body>

</html>