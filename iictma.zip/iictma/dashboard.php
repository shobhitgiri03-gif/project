<?php
session_start();
include("db.php");

// सुनिश्चित करें कि छात्र लॉगिन किया हो
if (!isset($_SESSION['EmailAddress'])) {
    header("Location: login.html");
    exit();
}

$email = $_SESSION['EmailAddress'];
$sql = "SELECT * FROM iicttv WHERE EmailAddress='$email'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="iict00.css">
    <style>
        body {
            font-family: Arial;
            background: #f4f6f9;
            margin: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            text-align: center;
        }
        .photo {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #0d6efd;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        .title {
            font-weight: bold;
            background: #0d6efd;
            color: white;
            width: 35%;
        }
        .logout {
            display: inline-block;
            margin-top: 20px;
            background: red;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($row['ProfilePhoto'])): ?>
            <img src="uploads/<?php echo $row['ProfilePhoto']; ?>" class="photo">
        <?php else: ?>
            <img src="uploads/default.png" class="photo">
        <?php endif; ?>

        <h2>Welcome, <?php echo htmlspecialchars($row['StudentName']); ?></h2>

        <table>
            <tr>
                <td class="title">Student Name</td>
                <td><?php echo htmlspecialchars($row['StudentName']); ?></td>
            </tr>
            <tr>
                <td class="title">Father Name</td>
                <td><?php echo htmlspecialchars($row['FatherName']); ?></td>
            </tr>
            <tr>
                <td class="title">Mobile Number</td>
                <td><?php echo htmlspecialchars($row['MobileNumber']); ?></td>
            </tr>
            <tr>
                <td class="title">Email</td>
                <td><?php echo htmlspecialchars($row['EmailAddress']); ?></td>
            </tr>
            <tr>
                <td class="title">Course</td>
                <td><?php echo htmlspecialchars($row['Course']); ?></td>
            </tr>
            <tr>
                <td class="title">Address</td>
                <td><?php echo htmlspecialchars($row['Address']); ?></td>
            </tr>
        </table>

        <a href="logout.php" class="logout">Logout</a>
        <a href="profile.php" class="btn">My Profile</a>
        <a href="edit_profile.php" class="btn">Edit Profile</a>
    </div>
</body>
</html>