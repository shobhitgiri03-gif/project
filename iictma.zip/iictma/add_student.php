<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

if(isset($_POST['save']))
{

$StudentName=$_POST['StudentName'];
$FatherName=$_POST['FatherName'];
$MobileNumber=$_POST['MobileNumber'];
$EmailAddress=$_POST['EmailAddress'];
$AadhaarNumber=$_POST['AadhaarNumber'];
$Course=$_POST['Course'];
$Address=$_POST['Address'];

$CreatePassword=password_hash($_POST['CreatePassword'],PASSWORD_DEFAULT);

$Status="Active";

$RegisterDate=date("Y-m-d");

$ProfilePhoto=$_FILES['ProfilePhoto']['name'];
$temp=$_FILES['ProfilePhoto']['tmp_name'];

move_uploaded_file($temp,"uploads/".$ProfilePhoto);

$stmt=$conn->prepare("INSERT INTO iicttv
(StudentName,FatherName,MobileNumber,EmailAddress,AadhaarNumber,Course,Address,ProfilePhoto,CreatePassword,Status,RegisterDate)
VALUES
(?,?,?,?,?,?,?,?,?,?,?)");

$stmt->bind_param("sssssssssss",
$StudentName,
$FatherName,
$MobileNumber,
$EmailAddress,
$AadhaarNumber,
$Course,
$Address,
$ProfilePhoto,
$CreatePassword,
$Status,
$RegisterDate);

if($stmt->execute())
{

echo "<script>

alert('Student Added Successfully');

window.location='students.php';

</script>";

}
else
{

echo mysqli_error($conn);

}

}
?>

<!DOCTYPE html>

<html>

<head>

<title>Add Student</title>

<link rel="stylesheet" href="iict00.css">

<style>

.container{

width:700px;
margin:40px auto;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,.2);

}

input,select,textarea{

width:100%;
padding:12px;
margin:10px 0;

}

button{

background:#0d6efd;
color:white;
padding:12px 30px;
border:none;
cursor:pointer;

}

</style>

</head>

<body>

<div class="container">

<h2>Add New Student</h2>

<form method="POST" enctype="multipart/form-data">

<input
type="text"
name="StudentName"
placeholder="Student Name"
required>

<input
type="text"
name="FatherName"
placeholder="Father Name"
required>

<input
type="text"
name="MobileNumber"
placeholder="Mobile Number"
required>

<input
type="email"
name="EmailAddress"
placeholder="Email Address"
required>

<input
type="text"
name="AadhaarNumber"
placeholder="Aadhaar Number"
required>

<select name="Course" required>

<option value="">Select Course</option>

<option>ADCA</option>

<option>DCA</option>

<option>CCA</option>

<option>CCC</option>

<option>TALLY</option>

<option>DTP</option>

<option>MS OFFICE</option>

<option>WEB DESIGNING</option>

<option>JAVA</option>

<option>PYTHON</option>

<option>DIGITAL MARKETING</option>

<option>O LEVEL</option>

</select>

<textarea
name="Address"
placeholder="Address"
required></textarea>

<input
type="password"
name="CreatePassword"
placeholder="Password"
required>

<label>Profile Photo</label>

<input
type="file"
name="ProfilePhoto"
required>

<button
type="submit"
name="save">

Save Student

</button>

</form>

</div>

</body>

</html>