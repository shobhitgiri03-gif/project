<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.html");
    exit();
}

include("db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>

<style>
body{
    margin:0;
    font-family:Arial, Helvetica, sans-serif;
    background:#f4f6f9;
}

.header{
    background:#0d6efd;
    color:white;
    padding:15px;
    text-align:center;
}

.container{
    width:90%;
    margin:30px auto;
}

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}

.card{
    background:#fff;
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,.1);
    text-align:center;
}

.card h2{
    color:#0d6efd;
    margin-bottom:15px;
}

.card p{
    font-size:28px;
    color:#198754;
    font-weight:bold;
}

.logout{
    text-align:center;
    margin-top:30px;
}

.logout a{
    text-decoration:none;
    background:red;
    color:white;
    padding:12px 25px;
    border-radius:5px;
}
</style>

</head>
<body>

<div class="header">
    <h1>Welcome Admin</h1>
</div>

<div class="container">

<div class="cards">

<div class="card">
<h2>Total Students</h2>
<p>
<?php
$total=0;
$q=mysqli_query($conn,"SELECT COUNT(*) AS total FROM iicttv");
if($q){
$row=mysqli_fetch_assoc($q);
$total=$row['total'];
}
echo $total;
?>
</p>
</div>

<div class="card">
<h2>Total Revenue</h2>
<p>
<?php
$revenue=0;
$q=mysqli_query($conn,"SELECT SUM(PaidFee) AS revenue FROM fees");
if($q){
$row=mysqli_fetch_assoc($q);
$revenue=$row['revenue'];
}
echo "₹".$revenue;
?>
</p>
</div>

<div class="card">
<h2>Pending Fee</h2>
<p>
<?php
$pending=0;
$q=mysqli_query($conn,"SELECT SUM(TotalFee-PaidFee) AS pending FROM fees");
if($q){
$row=mysqli_fetch_assoc($q);
$pending=$row['pending'];
}
echo "₹".$pending;
?>
</p>
</div>

<div class="card">
<h2>Today's Attendance</h2>
<p>
<?php
$attendance=0;
$q=mysqli_query($conn,"SELECT COUNT(*) AS attendance FROM attendance WHERE AttendanceDate=CURDATE()");
if($q){
$row=mysqli_fetch_assoc($q);
$attendance=$row['attendance'];
}
echo $attendance;
?>
</p>
</div>

</div>

<div class="logout">
<a href="admin_logout.php">Logout</a>
</div>

</div>

</body>
</html>