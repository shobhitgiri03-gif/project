<?php

session_start();

include("db.php");

if(isset($_GET['id']))
{

    $id = $_GET['id'];

    $sql = "DELETE FROM feedback WHERE FeedbackID='$id'";

    if(mysqli_query($conn,$sql))
    {

        echo "<script>

        alert('Feedback Deleted Successfully');

        window.location='feedback_report.php';

        </script>";

    }
    else
    {

        echo mysqli_error($conn);

    }

}
else
{

    echo "Invalid Request";

}

?>