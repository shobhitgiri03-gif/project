<?php

include("db.php");

$sql = "SELECT * FROM study_material ORDER BY MaterialID DESC";

$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Study Material</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{

font-family:Arial;

background:#f5f5f5;

margin:20px;

}

table{

width:100%;

border-collapse:collapse;

background:white;

}

table th,
table td{

border:1px solid #ddd;

padding:10px;

text-align:center;

}

table th{

background:#0d6efd;

color:white;

}

.download{

background:green;

color:white;

padding:8px 15px;

text-decoration:none;

border-radius:5px;

}

</style>

</head>

<body>

<h2 align="center">

Study Material

</h2>

<table>

<tr>

<th>ID</th>

<th>Title</th>

<th>Course</th>

<th>Upload Date</th>

<th>Download</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['MaterialID']; ?></td>

<td><?php echo $row['Title']; ?></td>

<td><?php echo $row['Course']; ?></td>

<td><?php echo $row['UploadDate']; ?></td>

<td>

<a
class="download"
href="materials/<?php echo $row['FileName']; ?>"
download>

Download

</a>

</td>

</tr>

<?php

}

?>

</table>

</body>

</html>