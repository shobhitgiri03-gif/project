<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['email']) && isset($_POST['password'])) {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);

            $sql = "SELECT * FROM admin WHERE email='$email' AND password='" . $password .  "'";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) == 1) {

            $_SESSION['admin'] = $email;
            header("Location: admin_dashboard.php"); 
            exit();
        } else {
            echo "<script>alert('Invalid Email or Password'); window.location='admin_login.html';</script>";
        }
    } else {
        echo "<script>alert('Please enter both email and password'); window.location='admin_login.html';</script>";
    }
} else {
    echo "<script>alert('Invalid Request'); window.location='admin_login.html';</script>";
}
?>