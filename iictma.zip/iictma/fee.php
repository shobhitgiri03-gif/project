<?php

session_start();

if(!isset($_SESSION['admin']))
{
    header("Location:admin_login.html");
    exit();
}

include("db.php");

$sql="SELECT
fees.*,
iicttv.StudentName,
iicttv.Course
FROM fees
INNER JOIN iicttv
ON fees.StudentID=iicttv.ID
ORDER BY fees.ID DESC";

$result=mysqli_query($conn,$sql);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Fee Management</title>

<link rel="stylesheet" href="iict00.css">

<style>

body{
background:#f4f6f9;
font-family:Arial;
}

.container{
width:96%;
margin:auto;
padding:30px;
}

table{
width:100%;
border-collapse:collapse;
background:white;
}

th{
background:#0d6efd;
color:white;
padding:12px;
}

td{
padding:10px;
border:1px solid #ddd;
text-align:center;
}

.btn{
padding:8px 15px;
text-decoration:none;
border-radius:5px;
color:white;
}

.green{
background:#198754;
}

.blue{
background:#0d6efd;
}

.search{
margin-bottom:20px;
}

.search input{
padding:10px;
width:300px;
}

</style>

</head>

<body>

<div class="container">

<h2>Fee Management</h2>

<a href="add_fee.php" class="btn green">
+ Collect Fee
</a>

<br><br>

<div class="search">

<input
type="text"
id="myInput"
placeholder="Search Student..."
onkeyup="searchFee()">

</div>

<table id="feeTable">

<tr>

<th>Receipt</th>

<th>Name</th>

<th>Course</th>

<th>Total Fee</th>

<th>Paid Fee</th>

<th>Pending</th>

<th>Date</th>

<th>Action</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['ReceiptNo']; ?></td>

<td><?php echo $row['StudentName']; ?></td>

<td><?php echo $row['Course']; ?></td>

<td>₹<?php echo $row['TotalFee']; ?></td>

<td>₹<?php echo $row['PaidFee']; ?></td>

<td>₹<?php echo $row['TotalFee']-$row['PaidFee']; ?></td>

<td><?php echo $row['FeeDate']; ?></td>

<td>

<a
class="btn blue"
href="print_receipt.php?id=<?php echo $row['ID']; ?>">

Print

</a>

</td>

</tr>

<?php

}

?>

</table>

</div>

<script>

function searchFee(){

var input=document.getElementById("myInput");

var filter=input.value.toUpperCase();

var table=document.getElementById("feeTable");

var tr=table.getElementsByTagName("tr");

for(var i=1;i<tr.length;i++){

var td=tr[i].getElementsByTagName("td")[1];

if(td){

txt=td.textContent||td.innerText;

tr[i].style.display=txt.toUpperCase().indexOf(filter)>-1?"":"none";

}

}

}

</script>

</body>

</html>