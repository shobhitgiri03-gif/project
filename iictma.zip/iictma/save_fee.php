<?php

include("db.php");

if(isset($_POST['save']))
{

    $StudentID = $_POST['StudentID'];
    $TotalFee = $_POST['TotalFee'];
    $PaidFee = $_POST['PaidFee'];
    $PaymentDate = $_POST['PaymentDate'];

    // Pending Fee Calculate
    $PendingFee = $TotalFee - $PaidFee;

    // Status
    if($PendingFee <= 0)
    {
        $Status = "Paid";
        $PendingFee = 0;
    }
    else
    {
        $Status = "Pending";
    }

    $sql = "INSERT INTO fees
    (StudentID, TotalFee, PaidFee, PendingFee, PaymentDate, Status)
    VALUES
    ('$StudentID','$TotalFee','$PaidFee','$PendingFee','$PaymentDate','$Status')";

    if(mysqli_query($conn,$sql))
    {

        // Student Name Fetch
        $student = mysqli_query($conn,"SELECT StudentName FROM iicttv WHERE id='$StudentID'");
        $data = mysqli_fetch_assoc($student);

        $StudentName = $data['StudentName'];

        // Activity Log
        $date = date("Y-m-d H:i:s");

        mysqli_query($conn,"
        INSERT INTO activity_log
        (StudentName,Activity,ActivityDate)
        VALUES
        ('$StudentName','Fee Paid','$date')
        ");

        echo "<script>

        alert('Fee Saved Successfully');

        window.location='fee_report.php';

        </script>";

    }
    else
    {

        echo "Error : ".mysqli_error($conn);

    }

}

?>