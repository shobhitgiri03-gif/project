<?php

session_start();

include("db.php");

$name=$_POST['Name'];
$email=$_POST['Email'];
$password=$_POST['Password'];

if(!empty($password))
{

mysqli_query($conn,"
UPDATE admin
SET
Name='$name',
Email='$email',
Password='$password'
");

}
else
{

mysqli_query($conn,"
UPDATE admin
SET
Name='$name',
Email='$email'
");

}

echo "<script>

alert('Profile Updated');

window.location='admin.php';

</script>";

?>