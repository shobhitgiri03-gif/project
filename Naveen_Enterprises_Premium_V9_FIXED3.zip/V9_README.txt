NAVEEN ENTERPRISES — V9

Built directly from V8 FINAL.

V9 additions:
- Website Content Manager: Hero, About, Services, Contact
- Social Links Manager: WhatsApp, Instagram, Facebook, YouTube
- Shared database APIs for public content
- Login attempt logging and temporary lockout
- Enquiry notes API
- Existing V8 modules retained

Run:
  node server.js

Admin:
  http://localhost:3000/admin

Default login:
  admin
  change-me-now

Change the password after first login.
